package com.yash.coreJavaProject;

import java.util.Date;
import java.util.Scanner;

public class SleeperClass implements TicketBookingSystemAPI {
	@Override
	public String BookTicket() {

		return "Tickets Available for first tier are 250";

	}

	@Override
	public void getTicket() {

		String name2 = "";
		String name3 = "";
		String name4 = "";

		System.out.println("Enter the Number of tickets you want to book");

		System.out.println();

		Scanner scanner = new Scanner(System.in);

		int number = scanner.nextInt();

		while (number > 4) {

			System.out.println("At a Time we can Book 4 Seats Only.Sorry for Inconvinience");

			System.out.println();

			System.out.println("Enter the Number of tickets you want to book");

			System.out.println();

			number = scanner.nextInt();
		}

		if (number < max && number < 5) {

			Scanner sc = new Scanner(System.in);

			System.out.println("Please name of First Passengers");

			String name1 = sc.nextLine();

			if (number > 1) {

				System.out.println("Please name of Second Passengers");

				name2 = sc.nextLine();
			}
			if (number > 2) {
				System.out.println("Please name of Third Passengers");

				name3 = sc.nextLine();
			}
			if (number > 3) {
				System.out.println("Please name of Fourth Passengers");

				name4 = sc.nextLine();
			}
			int b = (int) (Math.random() * (max - min + 1) + min);

			System.out.println();

			System.out.println(
					"Congratulations you have Booked Tickets for " + name1 + " and seat number is SL-" + (b - 4));

			if (number > 1) {
				System.out.println(
						"Congratulations you have Booked Tickets for " + name2 + " and seat number is SL-" + (b - 3));
			}
			if (number > 2) {
				System.out.println(
						"Congratulations you have Booked Tickets for " + name3 + " and seat number is SL-" + (b - 2));
			}

			if (number > 3) {
				System.out.println(
						"Congratulations you have Booked Tickets for " + name4 + " and seat numberc is SL-" + (b - 1));
			}

		}
		
		Date timenow = new Date();
		System.out.println();
		System.out.println("Date: " + timenow.toString());

		System.out.println("Your Booking Successful!!!");

		System.out.println("Please be polite,keep your place clean . Have a safe journey.");
		System.out.println("Support made in India!!!");
		System.out.println("!!Have a great day!!!");
		System.out.println();

	}

}