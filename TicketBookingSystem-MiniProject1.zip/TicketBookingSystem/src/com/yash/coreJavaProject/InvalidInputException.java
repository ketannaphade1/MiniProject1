package com.yash.coreJavaProject;

public class InvalidInputException extends RuntimeException {

	public InvalidInputException(String s) {
		super(s);

	}

}
