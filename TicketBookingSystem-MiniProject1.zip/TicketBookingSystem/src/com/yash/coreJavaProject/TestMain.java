package com.yash.coreJavaProject;

import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) {
		try {
			System.out.println("Welcome to Rail Recservation System");
			System.out.println();
			System.out.println("*******************************************************************");
			System.out.println();
			System.out.println("Enter the First/Second/Third/Sleeper/General Class Type");

			PublicClassBookingFactory pc = new PublicClassBookingFactory();

			Scanner scanner = new Scanner(System.in);

			String booking = scanner.next();

			if (booking.equalsIgnoreCase("First") || booking.equalsIgnoreCase("second")
					|| booking.equalsIgnoreCase("third") || booking.equalsIgnoreCase("sleeper")
					|| booking.equalsIgnoreCase("General")) {

				if (booking.length() > 1) {

					TicketBookingSystemAPI b = PublicClassBookingFactory.createBooking(booking);

					System.out.println(b.BookTicket());

					b.getTicket();

					System.out.println();

					scanner.close();

				}

			} else {
				System.out.println("You have entered wrong Option");
				System.out.println();
				main(args);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}