package com.yash.coreJavaProject;

public class PublicClassBookingFactory {

	public static TicketBookingSystemAPI createBooking(String input) {


		if (input.equalsIgnoreCase("First")) {

			return new FirstTier();

		}

		else if (input.equalsIgnoreCase("SECOND")) {
			return new SecondTier();
		}

		else if (input.equalsIgnoreCase("THIRD")) {
			return new ThirdTier();
		}

		else if (input.equalsIgnoreCase("SLEEPER")) {
			return new SleeperClass();
		}

		else if (input.equalsIgnoreCase("GENERAL")) {
			return new GeneralClass();
		}

		throw new InvalidInputException("The input is Invalid");

	}

}
