package com.yash.coreJavaProject;

import java.util.Scanner;


public interface TicketBookingSystemAPI {

	static int max = 72;
	static int min = 5;

	public String BookTicket();
	
	public void getTicket();



}
